<?php

//Conexión con la base de datos.
include('conection.php');

//Comenzar una sesión
session_start();

//Verificar si se esta enviando algún dato a través del formulario.
if(!isset($_POST['email'])){

    //Mensaje de error guardado en la sesión.
    $_SESSION['error'] = "Envie su correo a través del formulario";

    //Redireccionar a la vista 'forgot_password.php'
    header('Location:forgot_password.php');
}

else{ //Siguiente capa de validación.

    //Verificar si el campo 'email' esta vacio.
    if(empty($_POST['email'])){

        //Mensaje de error guardado en la sesión.
        $_SESSION['error'] = "El campo esta vacio, escriba su correo electronico";

        //Redireccionar a la vista 'forgot_password.php' 
        header('Location:forgot_password.php');
    }

else{ //Siguiente capa de validación.

    //verificar la conexion a la base de datos.
    if(mysqli_connect_errno()){

        //Mensaje de error guardado en la sesión.
        $_SESSION['error'] = "Error al conectar con la base de datos";

        //Redireccionar a la vista 'forgot_password.php'.
        header('Location:forgot_password.php');
     }

else{ //Siguiente capa de validación.

    //Parametros de la consulta para verificar si existe el correo electronico ingresado en el formulario
    $query = "SELECT * FROM form WHERE email = '$_POST[email]'";

    //Hacer la consulta en la base de datos
    $result = mysqli_query($conection, $query);

    //Cerrar conexion con la base de datos.
    #mysqli_close($conection);

    //Verificar el resultado de la consulta
    if(mysqli_num_rows($result)>0){

        //Obtener el correo del usuario.
        $email= $_POST['email'];

        //Genera un token para el usuario.
        $token= bin2hex(random_bytes(32));

        //Actualiza el campo de token.
        $query="UPDATE form SET token='$token' WHERE email='$email'";

        //Hacer consulta a la base de datos.
        mysqli_query($conection,$query);

        //Cerrar conexion con la base de datos.
        mysqli_close($conection);

        //Datos y configaración del correo a enviar.
        $from='Xtravel@gmail.com';
        $asunto="Recuperacion de contraseña";
        $mensaje="Hola\n\n puede usar el enlace para restablecer la contraseña:\n\n";
        $mensaje.="http://localhost/xtravel/forgot_password2.php?email=" . urlencode($email). "&token=" . urlencode($email);
        $headers= "from: $from\r\n";
        $headers.="Replay-to: $from\r\n";
        $headers.="content-type: text/plain\r\n";

            if(mail($email,$asunto,$mensaje,$headers)){

                //Mensaje de proceso satisfactorio guardado en la sesión.
                $_SESSION['success'] = "Le fue enviado un correo con el enlace para recuperar su clave";

                //Redireccionar a la vista 'forgot_password2.php'.
                header('Location:forgot_password.php');

                die();
            }

            else{ //Error al enviar el correo electronico

                //Mensaje de error guardado en la sesión.
                $_SESSION['error'] = "Error al enviar el correo";

                //Redireccionar a la vista 'forgot_password.php'.
                header('Location:forgot_password.php');
            }

            die();
        }

    else{ //Correo electronico no se encuentra en el sistema

        //Mensaje de error guardado en la sesión.
        $_SESSION['error'] = "Su usuario no esta registrado en nuestra plataforma";

        //Redireccionar a la vista 'forgot_password.php'.
        header('Location:forgot_password.php');

        die();

            }
        }
    }
}
?>