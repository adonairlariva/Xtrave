<?php

	//[PREG-MATCH]
	$preg_match_name = "/^[a-zA-Z0-9s]{3,20}$/";
	$preg_match_email = "/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$/";
	$preg_match_password = "/^(?=.*\d)(?=.*[a-zA-Z])[0-9a-zA-Z!@#$%]{8,}$/";
?>