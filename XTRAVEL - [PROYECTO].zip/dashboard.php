<?php
 
//Comenzar una sesión
 session_start();

?>

<!DOCTYPE HTML>
<html lang="es">
<head>

	<!--META-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!--TITLE-->
	<title>XTRAVEL - DASHBOARD</title>

	<!--STYLESHEET-->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="font/stylesheet.css">
	<link rel="stylesheet" href="icons/style.css">

	<!--JS-->
	<script src="js/sweetalert.min.js"></script>
	<script src="js/xtravel.js"></script>
<head>
<body>

	<?php if(isset($_SESSION['success'])){

		//Guardar el error en una variable
		$success = $_SESSION['success']; 
	?>

	<!--MOSTRAR ALERTAS-->
	<script>
	
		swal({
		  title: "¡Todo ha salido bien!",
		  text: "<?php echo $success ?>",
		  icon: "success",
		});

	</script>

	<?php } ?>

	<!--START NAVBAR-->
	<nav class="navbar navdown">

		<!--IMG AND TEXT-->
		<div class="logo-nav">

			<img src="img/logo.png" alt="logo.png" width="50" height="20">
			<h4><span>X</span>TRAVEL</h4>
		
		</div>

		<!--ITEMS-->
		<div class="items-nav">

			<a href="#" class="item-nav"></a>

			<a href="login.php" class="button-nav">¡LOGOUT!</a>

		</div>

		<input type="checkbox" id="check">
		<label for="check" class="icon-menu"></label>

	</nav>
	 <!--END NAVBAR-->

	  <h1><span class="icon-home"></span> DASHBOARD</h1>

</body>
</html>

<?php
 
 //Borrar variables de la sesión
 session_unset();

 //Destruir la sesión
 session_destroy();

?> 