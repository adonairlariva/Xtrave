<?php

	//Conexión con la base de datos
	$conection = mysqli_connect(
		'localhost', //HOST
		'root', //USER
		'', //PASSWORD
		'xtravel' //NAME_DATABASE
	);

?>