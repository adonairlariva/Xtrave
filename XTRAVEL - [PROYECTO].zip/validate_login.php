<?php 

//Conexión con la base de datos.
include('conection.php'); 

//Comenzar una sesión.
session_start();

if(!isset($_POST['email']) || !isset($_POST['password'])){ //Comprobar si se esta mandando algún datos desde el formulario.

	/*====================================
	
				[EXPLICACIÓN]

	1. Esta condicional sirve para proteger
	la ruta de 'validate_register.php' si
	es que se quiere acceder a ella desde la url.

	2.Se guarda un valor en la variable
	de sesión para mostrar una alerta
	referente a la causa del problema.

	3. Al final se redireciona al usuario
	a la misma vista.

	====================================*/

	$_SESSION['error'] = 'No se puede acceder a esa ruta'; //Mensaje de error guardado en la sesión.

	header('Location:login.php'); //Redireccionar a la vista 'login.php'.

	die();
}

else{ //Siguiente capa de validación.

	if(empty($_POST['email']) || empty($_POST['password'])){ //Verificia si se esta enviando algún dato desde el formulario.

		/*====================================
		
					[EXPLICACIÓN]

		1. Esta condicional sirve para verificar
		si NO se envia ningun dato a traves del
		formulario.

		2.Se guarda un valor en la variable
		de sesión para mostrar una alerta
		referente a la causa del problema.

		3. Al final se redireciona al usuario
		a la misma vista.

		====================================*/

		$_SESSION['error'] = 'Algunos de los campos esta vacio'; //Mensaje de error guardado en la sesión.

		header('Location:login.php'); //Redireccionar a la vista 'login.php'.

		die();
	}

else{ //Siguiente capa de validación.

		//Verificar si se pudo conectar con la base de datos.
		if(mysqli_connect_errno()){

			$_SESSION['error'] = 'Hubo un problema al conectar con la base de datos'; //Mensaje de error guardado en la sesión.

			header('Location:login.php'); //Redireccionar a la vista 'login.php'.

			die();
		}
else{

		/*====================================
		
					[EXPLICACIÓN]

		1. Primero se declaran los parametros
		de la consulta, en este caso se guarda
		en la variable '$query' y lo que se busca
		en la base de datos en un correo que
		coincida con el ingresado en el formulario.

		2.Se ejecuta la consulta y la respuesta
		se guarda en la variable '$result'.

		3.Se verififica la respuesta de la consulta
		mediante una condicional (if) y se busca
		si hubo resultado.

		4. Se verifica si la contraseña ingresada
		coincide con la de la base de datos.

		5. Dependiendo de si la operación fue exitosa
		o fallida, se redirecionará a diferentes vistas.
		Por ejemplo, si no hubo ningun problema
		en la validación de los datos se redireciona
		el usuario hacia la dashboard, de lo contrario
		se redireciona al usuario a la misma vista
		(register.php).

		6.Luego se guarda un valor en la variable
		de sesión para mostrar las alertas
		correspondintes a cada operación, bien
		sea exitosa o fallida.

		====================================*/

		//Guardar datos del formulario.
		$email = $_POST['email'];
		$password = $_POST['password'];


		//Parametros de la consulta para verificar si existe el correo electronico ingresado en el formulario.
		$query = "SELECT * FROM form WHERE email = '$email'";

		//Hacer la consulta en la base de datos.
		$result = mysqli_query($conection, $query);

		//Verificar si se encontró un correo electronico coincidiente.
		if($fila = mysqli_fetch_assoc($result)){ 

			//Verificar si la contraseña es correcta.
			if(password_verify($password, $fila['password'])){ 

				$_SESSION['success'] = '¡Su inicio de sesión ha sido satisfactorio!'; //Mensaje de error guardado en la sesión.

				$_SESSION['user']; //Autentificar al usuario mediante la sesión.

				header('Location:dashboard.php'); //Redireccionar a la vista 'dashboard.php'.

				msqli_close($conection); //Cerrar la conexión con la  base de datos.

				die();
			}

		else{ //La contraseña es incorrecta.

		$_SESSION['error'] = "Correo electronico ingresado erroneamente, verifique he intente de nuevo'"; //Mensaje de error guardado en la sesión.

		header('Location:login.php'); //Redireccionar a la vista 'login.php'.

		die(); 

			}
		}

		else{ //NO se encontró un correo coincidiente.

		$_SESSION['error'] = "Correo electronico ingresado erroneamente, verifique he intente de nuevo'"; //Mensaje de error guardado en la sesión

		header('Location:login.php'); //Redireccionar a la vista 'login.php'.

		die();
		
			}
		}
	}
}

?>