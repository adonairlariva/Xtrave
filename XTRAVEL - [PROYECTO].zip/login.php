<?php
 
//Comenzar una sesión
 session_start();

?>

<!DOCTYPE HTML>
<html lang="es">
<head>

	<!--META-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!--TITLE-->
	<title>XTRAVEL - INICIO DE SESIÓN</title>

	<!--STYLESHEET-->
	<link rel="stylesheet" href="css/form.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="font/stylesheet.css">
	<link rel="stylesheet" href="icons/style.css">

	<!--JS-->
	<script src="js/aos.js"></script>
	<script src="js/sweetalert.min.js"></script>
	<script src="js/xtravel.js"></script>

	<!--ICON-->
	<link rel="icon" href="img/logo.png">

</head>
<body>

	<?php if(isset($_SESSION['success'])){

		//Guardar el error en una variable
		$success = $_SESSION['success']; 
	?>

	<!--MOSTRAR ALERTAS-->
	<script>
	
		swal({
		  title: "¡Todo ha salido bien!",
		  text: "<?php echo $success ?>",
		  icon: "success",
		});

	</script>

	<?php } ?>


	<?php if(isset($_SESSION['error'])){

		//Guardar el error en una variable
		$error = $_SESSION['error']; 
	?>

	<!--MOSTRAR ERRORES -->
	<script>
	
		swal({
		  title: "¡Upss... Hubo un error!",
		  text: "<?php echo $error ?>",
		  icon: "error",
		});

	</script>

	<?php } ?>

	<!--START NAVBAR-->
	<nav class="navbar navdown">

		<!--IMG AND TEXT-->
		<div class="logo-nav">

			<img src="img/logo.png" alt="logo.png" width="50" height="20">
			<h4><span>X</span>TRAVEL</h4>
		
		</div>

		<!--ITEMS-->
		<div class="items-nav">

			<a href="#" class="item-nav">Inicio</a>
			<a href="#" class="item-nav">Servicio</a>
			<a href="#" class="item-nav">Contacto</a>
			<a href="#" class="item-nav">Sobre nosotros</a>

			<a href="register.php" class="button-nav">¡REGISTRO!</a>

		</div>

		<input type="checkbox" id="check">
		<label for="check" class="icon-menu"></label>

	</nav>
	 <!--END NAVBAR-->

	<!--START DESCRIPTION FORM-->
	<div class="form-description" data-aos="fade-right">

		<h1>¿SABIAS QUÉ?</h1>
		<p>¡Cada cierto tiempo lanzamos cupones de descuento para que puedan disfrutar de sus destinos favoritos a precios increibles. Para no perderte nada puedes estar atentos en nuestras redes sociales para no perderte ninguna promoción!</p>

	</div>
	<!--END DESCRIPTION FORM-->

	<!--START FORM-->
	<form action="validate_login.php" method="POST" class="form login" data-aos="fade-left">

		<!--HEAD FORM-->
		<div class="head-form">

			<img src="img/logo.png" alt="logo.png" width="50" height="20">
			<h4><span>X</span>TRAVEL</h4>

		</div>

		<!--BODY FORM-->
		<div class="body-form">

			<label>Correo Electrónico</label>
			<div class="item-body-form">
				<span class="icon-mail"></span><input type="email" name="email" placeholder=" Correo electrónico...">
			</div>

			<label>Contraseña</label>
			<div class="item-body-form">
				<span class="icon-key2"></span><input type="password" name="password" placeholder=" Contraseña...">
			</div>
			

		</div>

		<!--FOOTER FORM-->
		<div class="footer-form">

			<input type="submit" value="¡INICIAR SESIÓN!">

			<span>¿Olvido su contraseña?<a href="forgot_password.php"> ¡Restaurar ahora!</a></span>

		</div>

	</form>
	<!--END FORM-->

	<script>
		AOS.init({
			offset:120,
			delay:200,
			duration:1200,
			easing:'ease'
		});
	</script>

</body>
</html>

<?php
 
 //Borrar variables de la sesión
 session_unset();

 //Destruir la sesión
 session_destroy();

?> 