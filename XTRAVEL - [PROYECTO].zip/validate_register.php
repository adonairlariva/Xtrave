<?php 

//Conexión con la base de datos.
include('conection.php'); 

//Pregmatch.
include('prematch.php');

//Comenzar una sesión.
session_start();

if(!isset($_POST['name']) || !isset($_POST['email']) || !isset($_POST['password']) || !isset($_POST['repeatpassword'])){ //Comprobar si se esta mandando algún datos desde el formulario.

	/*====================================
	
				[EXPLICACIÓN]

	1. Esta condicional sirve para proteger
	la ruta de 'validate_register.php' si
	es que se quiere acceder a ella desde la url.

	2.Se guarda un valor en la variable
	de sesión para mostrar una alerta
	referente a la causa del problema.

	3. Al final se redireciona al usuario
	a la misma vista.

	====================================*/

	$_SESSION['error'] = 'No se puede acceder a esa ruta'; //Mensaje de error guardado en la sesión.

	header('Location:register.php'); //Redireccionar a la vista 'register.php'.

	die();
}

else{ //Siguiente capa de validación.

	if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['repeatpassword'])){ //Verificia si se esta enviando algún dato desde el formulario.

		/*====================================
		
					[EXPLICACIÓN]

		1. Esta condicional sirve para verificar
		si NO se envia ningun dato a traves del
		formulario.

		2.Se guarda un valor en la variable
		de sesión para mostrar una alerta
		referente a la causa del problema.

		3. Al final se redireciona al usuario
		a la misma vista.

		====================================*/

		$_SESSION['error'] = 'Algunos de los campos esta vacio'; //Mensaje de error guardado en la sesión.

		header('Location:register.php'); //Redireccionar a la vista 'register.php'.

		die();
	}

	else{ //Siguiente capa de validación.

		if($_POST['password'] != $_POST['repeatpassword']){ //Validar si las contraseñas introducidas son iguales.

		/*====================================
		
					[EXPLICACIÓN]

		1. Esta condicional sirve para verificar
		si las contraseñas introducidas, son
		diferentes.

		2.Se guarda un valor en la variable
		de sesión para mostrar una alerta
		referente a la causa del problema.

		3. Al final se redireciona al usuario
		a la misma vista.

		====================================*/

		$_SESSION['error'] = 'Las contraseñas no coinciden'; //Mensaje de error guardado en la sesión.

		header('Location:register.php'); //Redireccionar a la vista 'register.php'.

		die();
	}

	else{ //Siguiente capa de validación.

		/*====================================
		
					[EXPLICACIÓN]

		1. Primero se declaran los parametros
		de la consulta, en este caso se guarda
		en la variable '$query' y lo que se busca
		en la base de datos en un correo que
		coincida con el ingresado en el formulario.

		2.Se ejecuta la consulta y la respuesta
		se guarda en la variable '$result'.

		3.Se verififica la respuesta de la consulta
		mediante una condicional (if) y se busca
		si hubo resultado.

		4.Luego se guarda un valor en la variable
		de sesión para mostrar una alerta
		referente a la causa del problema.

		5. Al final se redireciona al usuario
		a la misma vista.

		====================================*/

		//Parametros de la consulta para verificar si existe el correo electronico ingresado en el formulario.
		$query = "SELECT * FROM form WHERE email = '$_POST[email]'";

		//Hacer la consulta en la base de datos.
		$result = mysqli_query($conection, $query);

		//Verificar el resultado de la consulta.
		if(mysqli_num_rows($result)>0){

			$_SESSION['error'] = 'El correo electronico ingresado ya se encuentra registrado'; //Mensaje de error guardado en la sesión.

			header('Location:register.php'); //Redireccionar a la vista 'register.php'.

			die();
		}

	else{ //Siguiente capa de validación.

		/*====================================
		
					[EXPLICACIÓN]

		1. Primero se establecen los caracteres
		validos para cada campo,gracias a la función
		'preg_match()'.

		2.Se validan los datos enviados a traves
		del formulario para saber si cumplen con
		los requisitos de los preg match'.

		3.Se valida tres veces para mostrar un
		mensaje de error correspondiente a cada
		campo.

		4.Luego se guarda un valor en la variable
		de sesión para mostrar una alerta
		referente a la causa del problema.

		5. Al final se redireciona al usuario
		a la misma vista.

		====================================*/

		//Se valida si el nombre enviado a traves del formulario no coincide con el pregmatch.
		if(!preg_match($preg_match_name,$_POST['name'])){

			$_SESSION['error'] = 'El nombre de usuario no es valido, verifique que tenga los siguientes requerimientos: Minimo: 5 letras. Maximo: 20 letras.NO contenener espacios ni caracteres especiales.'; //Mensaje de error guardado en la sesión.

			header('Location:register.php'); //Redireccionar a la vista 'register.php'.

			die();
		}

		//Se valida si el correo electronico enviado a traves del formulario no coincide con el pregmatch.
		if(!preg_match($preg_match_email,$_POST['email'])){

			$_SESSION['error'] = 'El correo electronico no es valido, verifique que este bien escrito'; //Mensaje de error guardado en la sesión.

			header('Location:register.php'); //Redireccionar a la vista 'register.php'.

			die();
		}

		//Se valida si la contraseña enviada a traves del formulario no coincide con el pregmatch.
		if(!preg_match($preg_match_password,$_POST['password'])){

			$_SESSION['error'] = 'La contraseña no es valida, asegúrese que al menos tenga 8 letras y es obligatorio que varie entre letras y numeros'; //Mensaje de error guardado en la sesión.

			header('Location:register.php'); //Redireccionar a la vista 'register.php'.

			die();
		}

	else{ //Siguiente capa de validación.

		/*====================================
		
					[EXPLICACIÓN]

		1. Se verifica si la conexión con la
		base de datos existe.

		2. De que no exista una conexión valida
		se guardar un mensajede error en la
		sesión y se redireccionaa la vista
		'register.php'.

		====================================*/


		//Verificar si se pudo conectar con la base de datos.
		if(mysqli_connect_errno()){

			$_SESSION['error'] = 'Hubo un problema al conectar con la base de datos'; //Mensaje de error guardado en la sesión.

			header('Location:register.php'); //Redireccionar a la vista 'register.php'.

			die();
		}

	else{ //Inserción de datos.

		/*====================================
		
					[EXPLICACIÓN]

		1.Se guardan todos los valores enviados
		desde el formulario es variables.

		2.Se cifra la contraseña mediante la
		función 'password_hash'.

		3.Se establece los parametros de la
		inserción en la variable '$insert'.

		4.Se hace la inserción en la base
		de datos.

		4.Luego se guarda un valor en la variable
		de sesión para mostrar una alerta
		de que el proceso fue realizado
		satisfactoriamente.

		6. Al final se redireciona al usuario
		a la vista de 'login.php'.

		7. Por ultimo se cierra la conexión
		con la base de datos.

		====================================*/

		//Guardar datos del formulario.
		$name = $_POST['name'];
		$email = $_POST['email'];
		$password = $_POST['password'];

		//Se cifra la contraseña.
		$hashPassword = password_hash($password, PASSWORD_DEFAULT);

		//Parametros para insertar los datos.
		$insert = "INSERT INTO form (name,email,password) VALUES ('$name','$email','$hashPassword')";

		//Insertar datos en la base de datos.
		mysqli_query($conection,$insert);
		
		$_SESSION['success'] = 'Su usuario se ha registrado correctamente'; //Mensaje de proceso exitoso guardado en la sesión.

		header('Location:login.php'); //Redireccionar a la vista 'login.php'.

		mysqli_close($conection); //Cerrar la conexión con la base de datos.

		die();
					
					}
				}
			}
		}
	}
}

?>