<?php

//Conexion con la base de datos.
include('conection.php');

include('prematch.php');

//Comenzar una sesión.
session_start();

//Verificar si se esta enviando algún dato a través del formulario.
if(!isset($_POST['token']) || !isset($_POST['password'])){

    //Mensaje de error guardado en la sesión.
    $_SESSION['error'] = "Alguno de los campos esta vacio";

    //Redireccionar a la vista 'forgot_password2.php'.
    header('Location:forgot_password2.php');

    die();
}

else{ //Siguiente capa de validación.

    //Verificar si el campo 'email' esta vacio.
    if(empty($_POST['token']) || empty($_POST['password'])){

        //Mensaje de error guardado en la sesión.
        $_SESSION['error'] = "El campo esta vacio, escriba su correo electronico";

        //Redireccionar a la vista 'forgot_password2.php' 
        header('Location:forgot_password2.php');

        die();
    }

else{ //Siguiente capa de validación.

    //verificar la conexion a la base de datos.
    if(mysqli_connect_errno()){

        //Mensaje de error guardado en la sesión.
        $_SESSION['error'] = "Error al conectar con la base de datos";

        //Redireccionar a la vista 'forgot_password2.php'.
        header('Location:forgot_password2.php');

        die();
     }

else{ //Siguiente capa de validación.

        //Se valida si la contraseña enviada a traves del formulario no coincide con el pregmatch
        if(!preg_match($preg_match_password,$_POST['password'])){

            $_SESSION['error'] = 'La contraseña no es valida, asegúrese que al menos tenga 8 letras y es obligatorio que varie entre letras y numeros'; //Mensaje de error guardado en la sesión

            header('Location:forgot_password2.php'); //Redireccionar a la vista 'register.php'

            die();
        }
else{

    //Capturar los valores del 'Token' y el 'Password'.
    $token = $_POST['token'];
    $newPassword = $_POST['password'];

    //Guardar datos de la URL.
    $email = $_SESSION['email'];

    //Borrar datos de sesión.
    unset($_SESSION['email']);

    session_encode();

    //Parametros de la consulta SQL.
    $query= "SELECT * FROM  xtravel WHERE token='$token' AND fecha_token >= DATE_SUB(NOW(), INTERVAL 1 HOUR)"; //Agregar 'fecha_token' (opcional).

    //Hacer la consulta en la base de datos.
    $resultado=mysqli_query($conetion,$query);

    //Verificar si se encontró un resultado coincidiente.
    if(mysqli_num_rows($resultado)==1){

        //Hashear el nuevo password.
        $hashedpassword = password_hash($newPassword, PASSWORD_DEFAULT);

        //Paremetro de la consulta para actualizar la contraseña.
        $query ="UPDATE xtravel SET token=NULL, password='$hashedpassword', fecha_token=NULL WHERE email='$email'";

        //Hacer la consulta en la base de datos.
        mysqli_query($conetion,$query);

        //Cerrar la conexion a la base de datos.
        mysqli_close($conetion);

        //Mensaje de proceso satisfactorio.
        $_SESSION['success'] = "Cambio de clave exitoso"; 

        //Redirección a la vista 'login.php'.
        header('Location:login.php');

        die();
    }

    else{
        //Mensaje de error guardado en la sesión.
        $_SESSION['error'] = 'Hubo un error al cambiar la clave, verifique he intente de nuevo';

        //Redirección a la vista 'forgot_password'.
        header('Location:forgot_password2.php');

        die();
                }
            }
        }
    }
}

?>