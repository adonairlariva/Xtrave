//Navbar color change
window.addEventListener('scroll', function(){
	var header = document.querySelector('nav');
	
	header.classList.toggle('navdown', window.scrollY<0 || window.scrollY<100);
});
